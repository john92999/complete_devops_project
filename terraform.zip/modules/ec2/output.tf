output "instance_ip" {
    value = [for i in aws_instance.complete_project_ec2: i.public_ip]
}

output "volume_id" {
    value = [for v in aws_ebs_volume.complete_project_ebs: v.id]
}