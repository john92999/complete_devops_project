resource "aws_s3_bucket" "complete_project" {
    bucket = var.aws_s3_bucket_name
    tags = {
        name = "complete_project_bucket"
    }
}