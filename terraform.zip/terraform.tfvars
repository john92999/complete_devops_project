ami_name = "ami-019715e0d74f695be"
instance_type_name = {
    dev = "t2.medium"
    prod = "t3.xlarge"
}
ebs_volumes = {
    volume1 = {
        size = 40
    }
}


#"terraform workspace new dev"  --> creating new dev workspace
#"terraform workspace select dev" this will select the dev workspace